package com.example.departmentconmikel.ui.department

import android.widget.ListAdapter
import com.example.departmentconmikel.data.Department

class DepartmentAdapter (

): ListAdapter<Department, DepartmentAdapter.DepartmentViewHolder