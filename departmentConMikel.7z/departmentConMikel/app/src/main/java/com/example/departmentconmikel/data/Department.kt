package com.example.departmentconmikel.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Department(val name:String, val city:String,): Parcelable
